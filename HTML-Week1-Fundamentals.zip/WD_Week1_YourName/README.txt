WEEK 1 HTML ASSIGNMENT

Files:
- task1.html: HTML Document Structure
- task2.html: Text Formatting & Basic Elements
- task3.html: Links, Images, Lists & Tables
- task4.html: Student Registration Form
- task5.html: Semantic HTML
- task6.html: Mini HTML Project
- reflection.html: Reflection & Learning

Before submission:
1. Open each HTML file in a browser and test it.
2. Replace "YourName" in the ZIP/folder name with your actual name.
3. Take screenshots if your instructor requires them.
4. Upload the ZIP file to Google Drive.
5. Set sharing to "Anyone with the link" and Viewer access.
6. Submit the Google Drive link on the internship portal.

Note: The image URLs in task3.html and task6.html require an internet connection.
